
import random 

list = []
list2 = []
i = 1
n = 1

diceRolls = {'1': 0, '2': 0, '3':0, '4':0, '5': 0, '6': 0, '7':0, 
'8':0, '9': 0, '10': 0, '11':0, '12':0
}
diceRolls2 = {'1': 0, '2': 0, '3':0, '4':0, '5': 0, '6': 0, '7':0, 
'8':0, '9': 0, '10': 0, '11':0, '12':0
}

while i <= 10000:
    list.append(random.randrange(1, 13))
    i +=1

for roll in diceRolls.keys():
    for num in list:
        if str(num) == roll:
            diceRolls[roll] += 1
for roll in diceRolls.keys():
    diceRolls[roll] /= i

while n <= 10000:
    list2.append(random.randint(1, 12))
    n +=1

for roll in diceRolls2.keys():
    for num in list2:
        if str(num) == roll:
            diceRolls2[roll] += 1

for roll in diceRolls2.keys():
    diceRolls2[roll] /= n

print(diceRolls)
print(f'Probability with random.range() is : {sum(diceRolls.values())/12}')
print(diceRolls2)
print(f'Probability with random.range() is : {sum(diceRolls2.values())/12}')
#10000/12 = 833.33

characters = [ {'name':'Gandolf','food': 5, 'grapefruit': 10, 'green potions': 7, 'red potions': 8, 'spells of enchantment': 10},
{'name':'Frodo', 'food': 0, 'kiwi': 5, 'wands of confusion': 7, 'green potions':8},
{'name': 'Sauron', 'bat wings': 5, 'evil spells': 10,'fire wands': 5}
]

class addCount:
    def __init__(self, name, item, oper, val):
        self.name = str(name)
        self.item = str(item)
        self.oper = str(oper)
        self.val = int(val)

    def operCount(self):
        if self.oper == '+':
            for x in characters:
                if characters[x]['name'] == self.name:
                    if characters[x]['item'] == self.item:
                        characters[x]['item'] += abs(self.val)
                        return characters[x]

        elif self.oper == '-':
            for x in characters:
                if characters[x]['name'] == self.name:
                    if characters[x]['item'] == self.item:
                        characters[x]['item'] -= abs(self.val)
                    

                        if characters[x]['item'] <= 0:
                            characters[x]['item'] = 0
                            print(f'{self.item} store is empty')
                    return characters[x]
        else:
            print('invalid input')

    def _str_(self):
        '''prints the string of the withdraw result'''
        return f'{self.operCount()}'

    def __repr__(self):
        '''references the withdraw result'''
        return f'{self.operCount()}'
class AddItem:
   
    def __init__(self, name, item, oper, count):
        self.name = str(name)
        self.item = str(item)
        self.oper = str(oper)
        self.count = int(count)

    def operItem(self):
        
        if self.oper == '+':
            for x in characters:
                if characters[x]['name'] == self.name:
                    if characters[x]['item'] == self.item:
                        characters[x]['item'] += abs(self.count)
                        print(characters[x])
    
        elif self.oper == '-':
            for x in characters:
                if characters[x]['name'] == self.name:
                    if characters[x]['item'] == self.item:
                        characters[x]['item'] -= abs(self.count)
                        print(characters[x])
                        if characters[x]['item'] <= 0:
                            characters[x]['item'] = 0
                            print(f'There is no more {self.item} \
                                {characters[x]}')
                    
        else:
            print('invalid input')

    def _str_(self):
        '''prints the string of the withdraw result'''
        return f'{self.operItem()}'

    def __repr__(self):
        '''references the withdraw result'''
        return f'{self.operItem()}'

class NewItem:
    def _init_(self, name, item, count):
        self.name = str(name)
        self.item = str(item)
        self.count = int(count)

    def NewItem(self):
        for x in characters:
            if characters[x]['name'] == self.name:
                characters[x].update({self.item: self.count})
                print(characters[x])
    def _str_(self):
        '''prints the string of the withdraw result'''
        return f'{self.NewItem()}'

    def __repr__(self):
        '''references the withdraw result'''
        return f'{self.NewItem()}'

class AddCharacter:
    def Add(self, name, items):
        self.name = str(name)
        self.items = items
        characters.update({self.name: self.items})
        print(characters)

    def _str_(self):
        '''prints the string of the withdraw result'''
        return f'{self.Add()}'

    def __repr__(self):
        '''references the withdraw result'''
        return f'{self.Add()}'

increment = addCount('Sauron', 'rings of power', '+', 5)
print(increment)
